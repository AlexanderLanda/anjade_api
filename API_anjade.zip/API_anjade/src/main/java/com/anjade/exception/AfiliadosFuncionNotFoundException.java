package com.anjade.exception;

public class AfiliadosFuncionNotFoundException extends RuntimeException{

	public AfiliadosFuncionNotFoundException(String message) {
		super(message);
	}
}
