package com.anjade.exception;

public class DeportesNotFoundException extends RuntimeException{

	public DeportesNotFoundException(String message) {
		super(message);
	}
}
