package com.anjade.exception;

public class AfiliadosCategoriasNotFoundException extends RuntimeException{

	public AfiliadosCategoriasNotFoundException(String message) {
		super(message);
	}
}
