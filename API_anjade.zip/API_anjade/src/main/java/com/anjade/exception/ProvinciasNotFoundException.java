package com.anjade.exception;

public class ProvinciasNotFoundException extends RuntimeException{

	public ProvinciasNotFoundException(String message) {
		super(message);
	}
}
