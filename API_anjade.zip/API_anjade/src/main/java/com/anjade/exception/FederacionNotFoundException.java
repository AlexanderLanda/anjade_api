package com.anjade.exception;

public class FederacionNotFoundException extends RuntimeException {

	public FederacionNotFoundException(String message) {
		super(message);
	}
}
