package com.anjade.exception;

public class EstadosUsuariosNotFoundException extends RuntimeException{

	public EstadosUsuariosNotFoundException(String message) {
		super(message);
	}
}
