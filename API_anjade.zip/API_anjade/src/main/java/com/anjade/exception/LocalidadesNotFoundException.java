package com.anjade.exception;

public class LocalidadesNotFoundException extends RuntimeException{

	public LocalidadesNotFoundException(String message) {
		super(message);
	}
}
