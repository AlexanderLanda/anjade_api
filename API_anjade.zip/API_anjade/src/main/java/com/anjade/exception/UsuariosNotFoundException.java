package com.anjade.exception;

public class UsuariosNotFoundException extends RuntimeException{

	public UsuariosNotFoundException(String message) {
		super(message);
	}
}
