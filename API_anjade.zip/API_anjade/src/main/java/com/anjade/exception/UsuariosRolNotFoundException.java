package com.anjade.exception;

public class UsuariosRolNotFoundException extends RuntimeException{

	public UsuariosRolNotFoundException(String message) {
		super(message);
	}
}
